<?php echo "=== Testing Composer Autoloader ===

"; require_once __DIR__ . "/vendor/autoload.php"; echo "✅ Composer autoloader loaded
"; if (class_exists("WindroseSubscription\Includes\Emails\WindroseSubscriptionActivatedEmail")) { echo "✅ Email class exists through autoloader
"; } else { echo "❌ Email class does NOT exist through autoloader
"; } echo "
=== Test Complete ===
";
