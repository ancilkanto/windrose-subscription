<?php
namespace WindroseSubscription\Includes\Emails;

use Automattic\WooCommerce\Utilities\FeaturesUtil;
use WindroseSubscription\Includes\WindroseWPMLIntegration;

if ( ! defined( 'ABSPATH' ) ) {
    // Only exit if we're in a WordPress context
    if (function_exists('add_action')) {
        exit;
    }
}

class WindroseSubscriptionActivatedEmail extends \WC_Email {
        public function __construct() {
            $this->id             = 'windrose_subscription_activated';
            $this->title          = 'Subscription Activated';
            $this->description    = 'This email is sent to the customer when their subscription is activated.';
            $this->template_html  = 'emails/windrose-subscription-activated.php';
            $this->template_plain = 'emails/plain/windrose-subscription-activated.php';
            $this->customer_email = true;
            $this->placeholders   = array();
            
            // Set default heading and subject
            $this->heading = 'Your subscription is now active!';
            $this->subject = 'Your subscription is now active';
            
            parent::__construct();
            
            // Ensure the email is enabled
            $this->ensure_email_enabled();
            
            // Delay WPML string registration until it's actually needed
            add_action('admin_init', array($this, 'register_wpml_strings'));
        }

        public function register_wpml_strings() {
            // Simple WPML registration without complex checks
            try {
                if (class_exists('WindroseSubscription\Includes\WindroseWPMLIntegration')) {
                    WindroseWPMLIntegration::register_email_strings(
                        $this->id,
                        $this->get_default_subject(),
                        $this->get_default_heading(),
                        $this->get_default_additional_content()
                    );
                }
            } catch (Exception $e) {
                // Silently fail if WPML integration has issues
            }
        }

        public function get_default_subject() {
            return __( 'Your subscription is now active', 'windros-subscription' );
        }

        public function get_default_heading() {
            return __( 'Your subscription is now active!', 'windros-subscription' );
        }

        public function get_default_additional_content() {
            return __( 'Thank you for subscribing to our service. We\'re excited to have you on board!', 'windros-subscription' );
        }

        public function init_form_fields() {
            /* translators: %s: list of placeholders */
            $placeholder_text = \sprintf( __( 'Available placeholders: %s', 'woocommerce' ), '<code>' . \esc_html( \implode( '</code>, <code>', \array_keys( $this->placeholders ) ) ) . '</code>' );
            
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __( 'Enable/Disable', 'woocommerce' ),
                    'type' => 'checkbox',
                    'label' => __( 'Enable this email notification', 'woocommerce' ),
                    'default' => 'yes',
                ),
                'subject' => array(
                    'title' => __( 'Subject', 'woocommerce' ),
                    'type' => 'text',
                    'desc_tip' => true,
                    'description' => $placeholder_text,
                    'placeholder' => $this->get_default_subject(),
                    'default' => '',
                    'custom_attributes' => WindroseWPMLIntegration::get_wpml_attributes($this->id, 'subject'),
                ),
                'heading' => array(
                    'title' => __( 'Email heading', 'woocommerce' ),
                    'type' => 'text',
                    'desc_tip' => true,
                    'description' => $placeholder_text,
                    'placeholder' => $this->get_default_heading(),
                    'default' => '',
                    'custom_attributes' => WindroseWPMLIntegration::get_wpml_attributes($this->id, 'heading'),
                ),
                'additional_content' => array(
                    'title' => __( 'Additional content', 'woocommerce' ),
                    'description' => __( 'Text to appear below the main email content.', 'woocommerce' ) . ' ' . $placeholder_text,
                    'css' => 'width:400px; height: 75px;',
                    'placeholder' => __( 'N/A', 'woocommerce' ),
                    'type' => 'textarea',
                    'default' => $this->get_default_additional_content(),
                    'desc_tip' => true,
                    'custom_attributes' => WindroseWPMLIntegration::get_wpml_attributes($this->id, 'additional_content'),
                ),
                'email_type' => array(
                    'title' => __( 'Email type', 'woocommerce' ),
                    'type' => 'select',
                    'description' => __( 'Choose which format of email to send.', 'woocommerce' ),
                    'default' => 'html',
                    'class' => 'email_type wc-enhanced-select',
                    'options' => $this->get_email_type_options(),
                    'desc_tip' => true,
                ),
            );
            
            if ( FeaturesUtil::feature_is_enabled( 'email_improvements' ) ) {
                $this->form_fields['cc'] = $this->get_cc_field();
                $this->form_fields['bcc'] = $this->get_bcc_field();
            }
        }

        public function admin_options() {
            // Do admin actions.
            $this->admin_actions();
            ?>
            <?php \wc_back_header( $this->get_title(), __( 'Return to emails', 'woocommerce' ), \admin_url( 'admin.php?page=wc-settings&tab=email' ) ); ?>

            <p><?php echo $this->get_description(); ?></p>

            <?php \do_action( 'woocommerce_email_settings_before', $this ); ?>

            <table class="form-table">
                <?php $this->generate_settings_html(); ?>
            </table>

            <?php \do_action( 'woocommerce_email_settings_after', $this ); ?>

            <script type="text/javascript">
            <?php echo WindroseWPMLIntegration::get_wpml_script(); ?>
            </script>

            <?php
            // ... rest of the admin_options method (template management) ...
        }

        public function get_subject() {
            $subject = $this->get_option_or_transient( 'subject', $this->get_default_subject() );
            $translated_subject = WindroseWPMLIntegration::get_translated_string($this->id, 'subject', $subject);
            
            return apply_filters( 'woocommerce_email_subject_' . $this->id, $this->format_string( $translated_subject ), $this->object, $this );
        }

        public function get_heading() {
            $heading = $this->get_option_or_transient( 'heading', $this->get_default_heading() );
            $translated_heading = WindroseWPMLIntegration::get_translated_string($this->id, 'heading', $heading);
            
            return apply_filters( 'woocommerce_email_heading_' . $this->id, $this->format_string( $translated_heading ), $this->object, $this );
        }

        public function get_additional_content() {
            $additional_content = $this->get_option_or_transient( 'additional_content', $this->get_default_additional_content() );
            $translated_content = WindroseWPMLIntegration::get_translated_string($this->id, 'additional_content', $additional_content);
            
            return apply_filters( 'woocommerce_email_additional_content_' . $this->id, $this->format_string( $translated_content ), $this->object, $this );
        }

        private function ensure_email_enabled() {
            // Simple approach - just set the properties without database operations
            // This avoids any potential issues with WordPress functions during instantiation
            $this->enabled = 'yes';
        }

        public function trigger( $subscription_id ) {
            \error_log('Windrose Subscription: Email trigger method called for subscription ID: ' . $subscription_id);
            if ( !$subscription_id ) {
                \error_log('Windrose Subscription: No subscription ID provided');
                return;
            }
            global $wpdb;
            $subscription_table = $wpdb->prefix . (defined('WINDROS_SUBSCRIPTION_MAIN_TABLE') ? WINDROS_SUBSCRIPTION_MAIN_TABLE : 'windrose_subscription_main');
            $subscription = $wpdb->get_row($wpdb->prepare("SELECT * FROM $subscription_table WHERE id = %d", $subscription_id));
            if (!$subscription) {
                \error_log('Windrose Subscription: No subscription found for ID: ' . $subscription_id);
                return;
            }
            $user = \get_userdata($subscription->user_id);
            $this->recipient = $user ? $user->user_email : '';
            $this->object = $subscription;
            
            // Explicitly set heading and subject
            $this->heading = $this->get_heading();
            $this->subject = $this->get_subject();
            
            \error_log('Windrose Subscription: Email recipient: ' . $this->recipient);
            \error_log('Windrose Subscription: Email enabled: ' . ($this->is_enabled() ? 'Yes' : 'No'));
            \error_log('Windrose Subscription: Email heading: ' . $this->heading);
            \error_log('Windrose Subscription: Email subject: ' . $this->subject);
            if ( ! $this->is_enabled() || ! $this->get_recipient() ) {
                \error_log('Windrose Subscription: Email not sent - disabled or no recipient');
                return;
            }
            \error_log('Windrose Subscription: Sending email to: ' . $this->get_recipient());
            
            // Force HTML content type
            \add_filter('wp_mail_content_type', function() {
                return 'text/html';
            });
            
            $result = $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
            \error_log('Windrose Subscription: Email send result: ' . ($result ? 'Success' : 'Failed'));
            
            // Remove the filter after sending
            \remove_all_filters('wp_mail_content_type');
        }

        public function get_headers() {
            $headers = parent::get_headers();
            
            // Ensure headers is an array
            if (!\is_array($headers)) {
                $headers = array();
            }
            
            // Ensure HTML content type
            $headers[] = 'Content-Type: text/html; charset=UTF-8';
            \error_log('Windrose Subscription: Email headers set to HTML: ' . \print_r($headers, true));
            return $headers;
        }

        public function get_content_html() {
            $template_path = \windrose_get_email_template_path();
            \error_log('Windrose Subscription: HTML template path: ' . $template_path . $this->template_html);
            \error_log('Windrose Subscription: Current heading: ' . $this->heading);
            \error_log('Windrose Subscription: Current subject: ' . $this->subject);
            
            $content = \wc_get_template_html( $this->template_html, array(
                'subscription' => $this->object,
                'email_heading' => $this->get_heading(),
                'email' => $this,
            ), '', $template_path );
            
            \error_log('Windrose Subscription: Generated HTML content length: ' . \strlen($content));
            return $content;
        }

        public function get_content_plain() {
            $template_path = \windrose_get_email_template_path();
            \error_log('Windrose Subscription: Plain template path: ' . $template_path . $this->template_plain);
            return \wc_get_template_html( $this->template_plain, array(
                'subscription' => $this->object,
                'email_heading' => $this->get_heading(),
                'email' => $this,
            ), '', $template_path );
        }
    }