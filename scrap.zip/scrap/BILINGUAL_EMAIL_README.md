# Bilingual Email Implementation for Windrose Subscription

This document explains how to use the bilingual email functionality for the "Subscription Activated" email in the Windrose Subscription plugin.

## Overview

The bilingual email approach displays subscription activation emails in both Arabic and English, providing a seamless multilingual experience for your customers. The implementation includes:

- **Dual Language Display**: Content shown in both Arabic (RTL) and English (LTR)
- **WPML Integration**: Full support for WPML String Translation
- **Customizable Content**: Subject, heading, and additional content fields
- **Responsive Design**: Mobile-friendly layout
- **Professional Styling**: Clean, modern design with language indicators

## Features

### 1. Bilingual Content Display
- **Arabic Section**: Right-to-left (RTL) layout with Arabic text
- **English Section**: Left-to-right (LTR) layout with English text
- **Language Badges**: Clear visual indicators for each language
- **Consistent Information**: Same subscription details in both languages

### 2. WPML Integration
- **Translation Buttons**: WPML translation buttons in email settings
- **String Registration**: Automatic registration of email strings with WPML
- **Language Switching**: Seamless language switching for email content
- **Context Management**: Proper WPML string context for translations

### 3. Customizable Fields
- **Subject**: Email subject line (translatable)
- **Heading**: Email heading (translatable)
- **Additional Content**: Extra information below main content (translatable)
- **Email Type**: HTML or plain text format

## Installation

The bilingual email functionality is automatically included with the Windrose Subscription plugin. No additional installation is required.

## Configuration

### 1. Access Email Settings

1. Go to **WooCommerce > Settings > Emails**
2. Click on **"Subscription Activated"** email
3. You'll see the enhanced form with WPML translation support

### 2. Configure Email Content

#### Subject Field
- **Default**: "Your subscription is now active"
- **WPML**: Click the translation button to add Arabic translation
- **Placeholders**: Supports WooCommerce placeholders

#### Heading Field
- **Default**: "Your subscription is now active!"
- **WPML**: Click the translation button to add Arabic translation
- **Placeholders**: Supports WooCommerce placeholders

#### Additional Content Field
- **Default**: "Thank you for subscribing to our service. We're excited to have you on board!"
- **WPML**: Click the translation button to add Arabic translation
- **Placeholders**: Supports WooCommerce placeholders

### 3. WPML Translation Setup

1. **Enable WPML String Translation Module**
   - Go to **WPML > String Translation**
   - Ensure the module is active

2. **Translate Email Strings**
   - Click translation buttons in email settings
   - WPML String Translation interface opens
   - Add translations for your target languages
   - Save translations

3. **String Context**
   - **Context**: `windros-subscription`
   - **Names**: 
     - `windrose_subscription_activated_subject`
     - `windrose_subscription_activated_heading`
     - `windrose_subscription_activated_additional_content`

## Email Templates

### HTML Template
- **Location**: `templates/emails/windrose-subscription-activated.php`
- **Features**: 
  - Responsive design
  - Language badges
  - Professional styling
  - CSS classes for customization

### Plain Text Template
- **Location**: `templates/emails/plain/windrose-subscription-activated.php`
- **Features**:
  - Clear language separation
  - Consistent formatting
  - Mobile-friendly layout

### CSS Styling
- **Location**: `assets/css/bilingual-email.css`
- **Features**:
  - RTL/LTR support
  - Responsive design
  - Professional color scheme
  - Customizable styles

## Testing

### 1. Test Email Functionality

1. **Run Test Script**
   - Access: `/wp-content/plugins/windrose-subscription/test-bilingual-email.php`
   - Click "Run Bilingual Email Test"
   - Verify all components are working

2. **Send Test Email**
   - Go to **WooCommerce > Settings > Emails**
   - Click **"Subscription Activated"**
   - Click **"Send test email"**
   - Check both HTML and plain text versions

### 2. Verify WPML Integration

1. **Check Translation Buttons**
   - Translation buttons should appear next to translatable fields
   - Buttons should open WPML String Translation interface

2. **Verify String Registration**
   - Go to **WPML > String Translation**
   - Search for `windros-subscription` context
   - Verify email strings are registered

## Customization

### 1. Modify Email Content

#### Add New Fields
```php
// In the email class
public function init_form_fields() {
    $this->form_fields['custom_field'] = array(
        'title' => __('Custom Field', 'windros-subscription'),
        'type' => 'text',
        'custom_attributes' => WindroseWPMLIntegration::get_wpml_attributes($this->id, 'custom_field'),
    );
}
```

#### Update Templates
```php
<!-- In the email template -->
<div class="arabic-content">
    <p><?php echo $email->get_custom_field(); ?></p>
</div>
<div class="english-content">
    <p><?php echo $email->get_custom_field(); ?></p>
</div>
```

### 2. Modify Styling

#### CSS Customization
```css
/* Customize Arabic section */
.arabic-section {
    background-color: #your-color;
    border-color: #your-border-color;
}

/* Customize English section */
.english-section {
    background-color: #your-color;
    border-color: #your-border-color;
}
```

#### Template Modifications
```php
<!-- Add custom classes -->
<div class="arabic-section custom-arabic-section">
    <!-- Content -->
</div>
```

## Troubleshooting

### Common Issues

#### 1. Translation Buttons Not Appearing
- **Cause**: WPML String Translation module not active
- **Solution**: Enable WPML String Translation module

#### 2. Translations Not Working
- **Cause**: Strings not registered with WPML
- **Solution**: Check string registration in WPML settings

#### 3. Email Not Sending
- **Cause**: Email not enabled or misconfigured
- **Solution**: Verify email settings in WooCommerce

#### 4. Styling Issues
- **Cause**: CSS not loading or conflicts
- **Solution**: Check CSS file path and browser console

### Debug Steps

1. **Run Test Script**
   - Use the provided test script to verify functionality
   - Check for error messages

2. **Check WPML Status**
   - Verify WPML is active and properly configured
   - Check String Translation module status

3. **Verify File Permissions**
   - Ensure template and CSS files are readable
   - Check plugin directory permissions

4. **Browser Console**
   - Check for JavaScript errors
   - Verify CSS is loading

## Support

### Getting Help

1. **Check This Documentation**: Review all sections thoroughly
2. **Run Test Script**: Use the provided test script
3. **Check WPML Status**: Verify WPML configuration
4. **Review Error Logs**: Check WordPress and WooCommerce logs

### Common Questions

**Q: Can I add more languages?**
A: Yes, WPML supports unlimited languages. Add translations through WPML String Translation.

**Q: How do I customize the email design?**
A: Modify the CSS file (`bilingual-email.css`) or override templates in your theme.

**Q: Can I use different content for different languages?**
A: Yes, WPML allows completely different content for each language.

**Q: Is the email responsive?**
A: Yes, the email template includes responsive CSS for mobile devices.

## Changelog

### Version 1.0.0
- Initial bilingual email implementation
- WPML integration support
- HTML and plain text templates
- Responsive CSS styling
- Test script for verification

## Compatibility

- **WordPress**: 5.0+
- **WooCommerce**: 5.0+
- **WPML**: 4.0+
- **PHP**: 7.4+
- **Browser**: Modern browsers with CSS3 support

## License

This implementation is part of the Windrose Subscription plugin and follows the same license terms.
