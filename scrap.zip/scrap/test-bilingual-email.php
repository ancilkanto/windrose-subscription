<?php
/**
 * Test Bilingual Email Functionality for Windrose Subscription
 * 
 * This script tests the bilingual email functionality for the subscription activated email.
 * Run this from the WordPress admin or via WP-CLI to test the email.
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    // If running from command line, load WordPress
    if (php_sapi_name() === 'cli') {
        $wp_load_path = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/wp-load.php';
        if (file_exists($wp_load_path)) {
            require_once $wp_load_path;
        } else {
            echo "Error: Could not load WordPress. Please run this from the WordPress admin.\n";
            exit(1);
        }
    } else {
        exit('Direct access not allowed.');
    }
}

// Check if user has admin capabilities
if (!current_user_can('manage_options')) {
    wp_die('You do not have sufficient permissions to access this page.');
}

// Test function
function test_bilingual_subscription_email() {
    echo "<h2>Testing Bilingual Subscription Activated Email</h2>";
    
    // Check if WPML is active
    if (function_exists('icl_register_string')) {
        echo "<p style='color: green;'>✓ WPML is active and available</p>";
    } else {
        echo "<p style='color: orange;'>⚠ WPML is not active - some features may not work</p>";
    }
    
    // Check if the email class exists
    if (class_exists('WindroseSubscription\Includes\Emails\WindroseSubscriptionActivatedEmail')) {
        echo "<p style='color: green;'>✓ WindroseSubscriptionActivatedEmail class exists</p>";
    } else {
        echo "<p style='color: red;'>✗ WindroseSubscriptionActivatedEmail class not found</p>";
        return;
    }
    
    // Check if WPML integration class exists
    if (class_exists('WindroseSubscription\Includes\WindroseWPMLIntegration')) {
        echo "<p style='color: green;'>✓ WindroseWPMLIntegration class exists</p>";
    } else {
        echo "<p style='color: red;'>✗ WindroseWPMLIntegration class not found</p>";
        return;
    }
    
    // Check if email templates exist
    $html_template = plugin_dir_path(__FILE__) . 'templates/emails/windrose-subscription-activated.php';
    $plain_template = plugin_dir_path(__FILE__) . 'templates/emails/plain/windrose-subscription-activated.php';
    $css_file = plugin_dir_path(__FILE__) . 'assets/css/bilingual-email.css';
    
    if (file_exists($html_template)) {
        echo "<p style='color: green;'>✓ HTML email template exists</p>";
    } else {
        echo "<p style='color: red;'>✗ HTML email template not found</p>";
    }
    
    if (file_exists($plain_template)) {
        echo "<p style='color: green;'>✓ Plain text email template exists</p>";
    } else {
        echo "<p style='color: red;'>✗ Plain text email template not found</p>";
    }
    
    if (file_exists($css_file)) {
        echo "<p style='color: green;'>✓ CSS file exists</p>";
    } else {
        echo "<p style='color: red;'>✗ CSS file not found</p>";
    }
    
    // Test email class instantiation
    try {
        $email = new WindroseSubscription\Includes\Emails\WindroseSubscriptionActivatedEmail();
        echo "<p style='color: green;'>✓ Email class instantiated successfully</p>";
        
        // Check form fields
        if (method_exists($email, 'init_form_fields')) {
            $email->init_form_fields();
            if (isset($email->form_fields['subject']) && isset($email->form_fields['heading'])) {
                echo "<p style='color: green;'>✓ Form fields initialized with WPML support</p>";
                
                // Check WPML attributes
                if (isset($email->form_fields['subject']['custom_attributes']['data-wpml-string'])) {
                    echo "<p style='color: green;'>✓ WPML attributes added to form fields</p>";
                } else {
                    echo "<p style='color: orange;'>⚠ WPML attributes not found in form fields</p>";
                }
            } else {
                echo "<p style='color: red;'>✗ Form fields not properly initialized</p>";
            }
        } else {
            echo "<p style='color: red;'>✗ init_form_fields method not found</p>";
        }
        
        // Check WPML string registration
        if (method_exists($email, 'register_wpml_strings')) {
            echo "<p style='color: green;'>✓ WPML string registration method exists</p>";
        } else {
            echo "<p style='color: orange;'>⚠ WPML string registration method not found</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>✗ Error instantiating email class: " . $e->getMessage() . "</p>";
    }
    
    // Test WPML integration methods
    if (class_exists('WindroseSubscription\Includes\WindroseWPMLIntegration')) {
        $wpml_methods = [
            'register_email_strings',
            'get_translated_string',
            'get_wpml_attributes',
            'get_wpml_script',
            'is_wpml_active'
        ];
        
        foreach ($wpml_methods as $method) {
            if (method_exists('WindroseSubscription\Includes\WindroseWPMLIntegration', $method)) {
                echo "<p style='color: green;'>✓ WPML method '{$method}' exists</p>";
            } else {
                echo "<p style='color: red;'>✗ WPML method '{$method}' not found</p>";
            }
        }
        
        // Test WPML active check
        $is_wpml_active = WindroseSubscription\Includes\WindroseWPMLIntegration::is_wpml_active();
        echo "<p style='color: " . ($is_wpml_active ? 'green' : 'orange') . ";'>" . 
             ($is_wpml_active ? '✓' : '⚠') . " WPML active check: " . ($is_wpml_active ? 'Yes' : 'No') . "</p>";
    }
    
    // Test email template rendering
    if (class_exists('WindroseSubscription\Includes\Emails\WindroseSubscriptionActivatedEmail')) {
        try {
            $email = new WindroseSubscription\Includes\Emails\WindroseSubscriptionActivatedEmail();
            
            // Create a mock subscription object
            $mock_subscription = (object) [
                'id' => 999,
                'user_id' => 1,
                'product_id' => 1,
                'quantity' => 2,
                'schedule' => 'weekly'
            ];
            
            $email->object = $mock_subscription;
            $email->recipient = 'test@example.com';
            
            // Test HTML content generation
            if (method_exists($email, 'get_content_html')) {
                $html_content = $email->get_content_html();
                if (!empty($html_content)) {
                    echo "<p style='color: green;'>✓ HTML content generated successfully</p>";
                    
                    // Check if bilingual content is present
                    if (strpos($html_content, 'arabic-section') !== false && strpos($html_content, 'english-section') !== false) {
                        echo "<p style='color: green;'>✓ Bilingual content detected in HTML</p>";
                    } else {
                        echo "<p style='color: orange;'>⚠ Bilingual content not detected in HTML</p>";
                    }
                } else {
                    echo "<p style='color: red;'>✗ HTML content generation failed</p>";
                }
            }
            
            // Test plain text content generation
            if (method_exists($email, 'get_content_plain')) {
                $plain_content = $email->get_content_plain();
                if (!empty($plain_content)) {
                    echo "<p style='color: green;'>✓ Plain text content generated successfully</p>";
                    
                    // Check if bilingual content is present
                    if (strpos($plain_content, 'ARABIC VERSION') !== false && strpos($plain_content, 'ENGLISH VERSION') !== false) {
                        echo "<p style='color: green;'>✓ Bilingual content detected in plain text</p>";
                    } else {
                        echo "<p style='color: orange;'>⚠ Bilingual content not detected in plain text</p>";
                    }
                } else {
                    echo "<p style='color: red;'>✗ Plain text content generation failed</p>";
                }
            }
            
        } catch (Exception $e) {
            echo "<p style='color: red;'>✗ Error testing email template rendering: " . $e->getMessage() . "</p>";
        }
    }
    
    echo "<h3>Test Summary</h3>";
    echo "<p>This test verifies that the bilingual email functionality is properly implemented.</p>";
    echo "<p>To test the actual email sending:</p>";
    echo "<ol>";
    echo "<li>Go to WooCommerce > Settings > Emails</li>";
    echo "<li>Click on 'Subscription Activated' email</li>";
    echo "<li>You should see WPML translation buttons next to Subject, Heading, and Additional Content fields</li>";
    echo "<li>Configure the email settings and send a test email</li>";
    echo "</ol>";
    
    echo "<p><strong>Note:</strong> Make sure you have WPML String Translation module activated for full functionality.</p>";
}

// Run the test
if (isset($_GET['test_bilingual_email']) || (defined('WP_CLI') && WP_CLI)) {
    test_bilingual_subscription_email();
} else {
    echo "<h2>Bilingual Email Test</h2>";
    echo "<p>Click the button below to test the bilingual email functionality:</p>";
    echo "<a href='?test_bilingual_email=1' class='button button-primary'>Run Bilingual Email Test</a>";
}
?>
