<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Windrose Subscription Activated Email (Plain Text) - Bilingual Version
 *
 * @var $subscription object
 * @var $email_heading string
 * @var $email WC_Email
 */
?>
<?php echo $email_heading; ?>

<?php echo str_repeat('=', 60); ?>
<?php echo __('ARABIC VERSION / النسخة العربية', 'windros-subscription'); ?>
<?php echo str_repeat('=', 60); ?>

<?php echo __('تم تفعيل اشتراكك!', 'windros-subscription'); ?>

<?php printf( __( 'مرحباً، اشتراكك (الرقم: %d) أصبح الآن نشطاً.', 'windros-subscription' ), $subscription->id ); ?>

<?php printf( __( 'المنتج: %s', 'windros-subscription' ), get_the_title($subscription->product_id) ); ?>
<?php printf( __( 'الكمية: %d', 'windros-subscription' ), $subscription->quantity ); ?>
<?php printf( __( 'الجدول الزمني: %s', 'windros-subscription' ), defined('WINDROS_FREQUENCY') && isset(WINDROS_FREQUENCY[$subscription->schedule]) ? WINDROS_FREQUENCY[$subscription->schedule] : $subscription->schedule ); ?>
<?php printf( __( 'تاريخ التوصيل القادم: %s', 'windros-subscription' ), windrose_get_next_delivery_date($subscription->id) ); ?>

<?php if ( $email->get_additional_content() ) : ?>
<?php echo __('محتوى إضافي:', 'windros-subscription'); ?>
<?php echo wpautop( wptexturize( $email->get_additional_content() ) ); ?>
<?php endif; ?>

<?php echo str_repeat('=', 60); ?>
<?php echo __('ENGLISH VERSION / النسخة الإنجليزية', 'windros-subscription'); ?>
<?php echo str_repeat('=', 60); ?>

<?php echo __('Your Subscription is Now Active!', 'windros-subscription'); ?>

<?php printf( __( 'Hello, your subscription (ID: %d) is now active.', 'windros-subscription' ), $subscription->id ); ?>

<?php printf( __( 'Product: %s', 'windros-subscription' ), get_the_title($subscription->product_id) ); ?>
<?php printf( __( 'Quantity: %d', 'windros-subscription' ), $subscription->quantity ); ?>
<?php printf( __( 'Schedule: %s', 'windros-subscription' ), defined('WINDROS_FREQUENCY') && isset(WINDROS_FREQUENCY[$subscription->schedule]) ? WINDROS_FREQUENCY[$subscription->schedule] : $subscription->schedule ); ?>
<?php printf( __( 'Next Delivery Date: %s', 'windros-subscription' ), windrose_get_next_delivery_date($subscription->id) ); ?>

<?php if ( $email->get_additional_content() ) : ?>
<?php echo __('Additional Information:', 'windros-subscription'); ?>
<?php echo wpautop( wptexturize( $email->get_additional_content() ) ); ?>
<?php endif; ?>

<?php echo apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) ); ?> 