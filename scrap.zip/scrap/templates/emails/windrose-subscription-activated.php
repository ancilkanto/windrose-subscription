<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Windrose Subscription Activated Email (HTML) - Bilingual Version
 *
 * @var $subscription object
 * @var $email_heading string
 * @var $email WC_Email
 */
?>
<?php do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<link rel="stylesheet" href="<?php echo esc_url(plugins_url('assets/css/bilingual-email.css', dirname(dirname(__FILE__)))); ?>" type="text/css" />

<!-- Arabic Section First -->
<div class="arabic-section">
    <div class="language-badge">العربية</div>
    <div class="arabic-content">
        <h2><?php _e( 'تم تفعيل اشتراكك!', 'windros-subscription' ); ?></h2>
        <p><?php printf( __( 'مرحباً، اشتراكك (الرقم: %d) أصبح الآن <strong>نشطاً</strong>.', 'windros-subscription' ), $subscription->id ); ?></p>
        <p><?php printf( __( 'المنتج: %s', 'windros-subscription' ), get_the_title($subscription->product_id) ); ?></p>
        <p><?php printf( __( 'الكمية: %d', 'windros-subscription' ), $subscription->quantity ); ?></p>
        <p><?php printf( __( 'الجدول الزمني: %s', 'windros-subscription' ), defined('WINDROS_FREQUENCY') && isset(WINDROS_FREQUENCY[$subscription->schedule]) ? WINDROS_FREQUENCY[$subscription->schedule] : $subscription->schedule ); ?></p>
        <p><?php printf( __( 'تاريخ التوصيل القادم: %s', 'windros-subscription' ), windrose_get_next_delivery_date($subscription->id) ); ?></p>
        
        <?php if ( $email->get_additional_content() ) : ?>
            <div class="arabic-content">
                <h3><?php _e( 'محتوى إضافي:', 'windros-subscription' ); ?></h3>
                <?php echo wpautop( wptexturize( $email->get_additional_content() ) ); ?>
            </div>
        <?php endif; ?>
    </div>
</div> <!-- End Arabic Section -->

<!-- English Section Second -->
<div class="english-section">
    <div class="language-badge">English</div>
    <div class="english-content">
        <h2><?php _e( 'Your Subscription is Now Active!', 'windros-subscription' ); ?></h2>
        <p><?php printf( __( 'Hello, your subscription (ID: %d) is now <strong>active</strong>.', 'windros-subscription' ), $subscription->id ); ?></p>
        <p><?php printf( __( 'Product: %s', 'windros-subscription' ), get_the_title($subscription->product_id) ); ?></p>
        <p><?php printf( __( 'Quantity: %d', 'windros-subscription' ), $subscription->quantity ); ?></p>
        <p><?php printf( __( 'Schedule: %s', 'windros-subscription' ), defined('WINDROS_FREQUENCY') && isset(WINDROS_FREQUENCY[$subscription->schedule]) ? WINDROS_FREQUENCY[$subscription->schedule] : $subscription->schedule ); ?></p>
        <p><?php printf( __( 'Next Delivery Date: %s', 'windros-subscription' ), windrose_get_next_delivery_date($subscription->id) ); ?></p>
        
        <?php if ( $email->get_additional_content() ) : ?>
            <div class="english-content">
                <h3><?php _e( 'Additional Information:', 'windros-subscription' ); ?></h3>
                <?php echo wpautop( wptexturize( $email->get_additional_content() ) ); ?>
            </div>
        <?php endif; ?>
    </div>
</div> <!-- End English Section -->

<?php do_action( 'woocommerce_email_footer', $email ); ?> 
