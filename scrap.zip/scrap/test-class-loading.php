<?php
echo "=== Windrose Subscription Class Loading Test ===\n\n";

$class_file = __DIR__ . '/includes/emails/WindroseSubscriptionActivatedEmail.php';
if (file_exists($class_file)) {
    echo "✅ Email class file exists\n";
} else {
    echo "❌ Email class file NOT found\n";
    exit;
}

try {
    require_once $class_file;
    echo "✅ Email class file included successfully\n";
} catch (Exception $e) {
    echo "❌ Error including email class file: " . $e->getMessage() . "\n";
    exit;
}

if (class_exists('WindroseSubscription\Includes\Emails\WindroseSubscriptionActivatedEmail')) {
    echo "✅ Email class exists after including\n";
} else {
    echo "❌ Email class does NOT exist after including\n";
    exit;
}

echo "\n=== Test Complete ===\n";
