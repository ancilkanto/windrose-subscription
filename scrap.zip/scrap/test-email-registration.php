<?php
/**
 * Test script to verify email class registration
 */

echo "=== Windrose Subscription Email Registration Test ===\n\n";

// Check if our email class exists
if (class_exists('WindroseSubscription\Includes\Emails\WindroseSubscriptionActivatedEmail')) {
    echo "✅ WindroseSubscriptionActivatedEmail class exists\n";
} else {
    echo "❌ WindroseSubscriptionActivatedEmail class does NOT exist\n";
}

// Check if WordPress functions are available
$functions = ['wp_autop', 'wp_kses_post', 'get_option', 'update_option'];
echo "\n=== WordPress Function Availability ===\n";
foreach ($functions as $func) {
    if (function_exists($func)) {
        echo "✅ $func() is available\n";
    } else {
        echo "❌ $func() is NOT available\n";
    }
}

echo "\n=== Test Complete ===\n";
