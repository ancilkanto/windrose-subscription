<?php
/**
 * Test Email Class Instantiation
 * 
 * This script tests if the WindroseSubscriptionActivatedEmail class can be instantiated
 * without errors.
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    // If running from command line, load WordPress
    if (php_sapi_name() === 'cli') {
        $wp_load_path = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/wp-load.php';
        if (file_exists($wp_load_path)) {
            require_once $wp_load_path;
        } else {
            echo "Error: Could not load WordPress. Please run this from the WordPress admin.\n";
            exit(1);
        }
    } else {
        exit('Direct access not allowed.');
    }
}

// Check if user has admin capabilities
if (!current_user_can('manage_options')) {
    wp_die('You do not have sufficient permissions to access this page.');
}

// Test function
function test_email_instantiation() {
    echo "<h2>Testing Email Class Instantiation</h2>";
    
    // Check if WooCommerce is active
    if (!class_exists('WC_Email')) {
        echo "<p style='color: red;'>✗ WooCommerce is not active</p>";
        return;
    } else {
        echo "<p style='color: green;'>✓ WooCommerce is active</p>";
    }
    
    // Check if the email class file exists
    $email_class_file = plugin_dir_path(__FILE__) . 'includes/emails/WindroseSubscriptionActivatedEmail.php';
    if (file_exists($email_class_file)) {
        echo "<p style='color: green;'>✓ Email class file exists</p>";
    } else {
        echo "<p style='color: red;'>✗ Email class file not found</p>";
        return;
    }
    
    // Check if the class exists
    if (class_exists('WindroseSubscription\Includes\Emails\WindroseSubscriptionActivatedEmail')) {
        echo "<p style='color: green;'>✓ Email class exists</p>";
    } else {
        echo "<p style='color: red;'>✗ Email class not found</p>";
        return;
    }
    
    // Try to instantiate the class
    try {
        $email = new WindroseSubscription\Includes\Emails\WindroseSubscriptionActivatedEmail();
        echo "<p style='color: green;'>✓ Email class instantiated successfully</p>";
        
        // Check basic properties
        if (isset($email->id) && $email->id === 'windrose_subscription_activated') {
            echo "<p style='color: green;'>✓ Email ID is correct: " . $email->id . "</p>";
        } else {
            echo "<p style='color: orange;'>⚠ Email ID is not set correctly</p>";
        }
        
        if (isset($email->title) && !empty($email->title)) {
            echo "<p style='color: green;'>✓ Email title is set: " . $email->title . "</p>";
        } else {
            echo "<p style='color: orange;'>⚠ Email title is not set</p>";
        }
        
        // Check if form fields can be initialized
        if (method_exists($email, 'init_form_fields')) {
            try {
                $email->init_form_fields();
                if (isset($email->form_fields) && is_array($email->form_fields)) {
                    echo "<p style='color: green;'>✓ Form fields initialized successfully</p>";
                    echo "<p>Number of form fields: " . count($email->form_fields) . "</p>";
                } else {
                    echo "<p style='color: orange;'>⚠ Form fields not properly initialized</p>";
                }
            } catch (Exception $e) {
                echo "<p style='color: red;'>✗ Error initializing form fields: " . $e->getMessage() . "</p>";
            }
        } else {
            echo "<p style='color: red;'>✗ init_form_fields method not found</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>✗ Error instantiating email class: " . $e->getMessage() . "</p>";
        echo "<p>Error details: " . $e->getTraceAsString() . "</p>";
    }
    
    echo "<h3>Test Summary</h3>";
    echo "<p>This test verifies that the email class can be instantiated without errors.</p>";
    echo "<p>If all checks pass, the email class should work properly in the WooCommerce admin.</p>";
}

// Run the test
if (isset($_GET['test_email_instantiation']) || (defined('WP_CLI') && WP_CLI)) {
    test_email_instantiation();
} else {
    echo "<h2>Email Class Instantiation Test</h2>";
    echo "<p>Click the button below to test the email class instantiation:</p>";
    echo "<a href='?test_email_instantiation=1' class='button button-primary'>Run Email Class Test</a>";
}
?>
